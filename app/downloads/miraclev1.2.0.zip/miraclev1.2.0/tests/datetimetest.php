<?php


// echo date("l, d/m/Y, g:iA", strtotime("+1month +1hour"));