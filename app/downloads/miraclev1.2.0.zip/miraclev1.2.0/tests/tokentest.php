<?php

// $token = Token::generate(md5(bin2hex(random_bytes(32))));

// Session::set("CLIENT_TOKEN", $token);

// // Session::destroy("CLIENT_TOKEN");

// if (Token::verify($token, Session::get("CLIENT_TOKEN"))) {
//     echo "true";
// } else {
//     echo "false";
// }